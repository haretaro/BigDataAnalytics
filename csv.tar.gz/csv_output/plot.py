import numpy as np
import os
import pandas as pd

def load_csvs(target, columns):
    l = []
    for directory, _, files in os.walk(target):
        for filename in files:
            _, ext = os.path.splitext(filename)
            if ext == '.csv':
                d = pd.read_csv(os.path.join(directory, filename), header=None, dtype={0:'str', 1:'int'})
                l.append(d)
    df = pd.concat(l)
    df.columns = columns
    return df

wcount = load_csvs('wcount', ['date', 'wcount'])
count = load_csvs('comment_count', ['date', 'count'])
df = count.merge(wcount)
df['ratio'] = df['wcount'] / df['count']
print(df)

